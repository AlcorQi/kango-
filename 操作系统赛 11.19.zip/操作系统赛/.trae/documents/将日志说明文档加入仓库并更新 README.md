## 将新增的文档
- 新增 `docs/log-sources.md`，整理本项目所覆盖的 Linux 日志来源与说明。
- 文档内容结构：
  1. 检测范围（递归 `/var/log`、识别常见日志、支持 `.gz`、在 Linux 时读取 `journalctl`）
  2. 日志类别与说明（syslog/messages、kern.log、dmesg、auth/secure、audit、boot/daemon/cron、Xorg/GPU/VM、dpkg/apt/yum/pacman、cups、cloud-init、installer、fontconfig 等）
  3. 旋转与压缩（`.log.N`/`.N.gz` 识别与读取、二进制日志排除、跳过 `/var/log/journal` 二进制）
  4. systemd 日志（`journalctl -o short-iso --no-pager` 文本输出纳入检测）
  5. 检测器与关键词（OOM/Panic/Reboot 的关键词来源与示例）
  6. 配置与扩展（`config/default.yaml` 的 `log_paths` 用法、如何添加/排除目录与文件）
  7. 使用建议与权限说明（Linux 环境运行、`sudo` 权限、发行版差异）
  8. 局限与后续扩展（支持更多压缩格式、特定服务日志如 nginx/ssh、正则匹配增强）

## 更新 README
- 在 README 顶部新增“日志来源与说明”章节，简要概述并链接到 `docs/log-sources.md`。
- 在“快速开始/运行”章节中补充：Linux 环境下运行示例与权限提示，不在 Windows 环境执行。
- 在“配置”章节中补充：`log_paths` 默认包含 `/var/log`，可追加应用日志目录（如 `/var/log/nginx`）。

## 变更范围
- 仅新增文档文件并修改 `README.md`，不改动任何代码逻辑。
- 不执行或运行程序，符合当前 Windows 环境限制。

## 交付方式
- 按上述结构撰写完整内容并提交到仓库。
- 如你有特定版式或语言（中文/英文）偏好，可告知后我再调整文档措辞。