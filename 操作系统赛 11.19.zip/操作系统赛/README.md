# 操作系统异常信息检测工具

该工具用于在 Linux 系统中递归扫描日志并进行异常检测（OOM、Kernel panic、异常重启）。默认覆盖 `/var/log` 全目录，支持读取压缩旋转日志与 `systemd` 的 `journalctl` 文本输出。

## 日志来源与说明
- 完整说明文档请查看：`docs/log-sources.md`
- 主要覆盖：系统总览（syslog/messages）、内核（kern.log/dmesg）、认证安全（auth/audit）、启动与服务（boot/daemon/cron）、图形与外设（Xorg/GPU/VM）、包管理与升级（dpkg/apt/yum/pacman）、打印与系统服务（cups）、云与安装器（cloud-init/installer）等。

## 快速开始
- 配置文件：`config/default.yaml`
- 示例（Linux 环境运行）：
  - `python src/main.py -c config/default.yaml`
  - 自定义输出路径：`python src/main.py -c config/default.yaml -o reports/os_report.txt`
- 注意：当前系统为 Windows 时请勿运行，实际日志读取与 `journalctl` 仅在 Linux 环境有效。

## 配置
- `log_paths`：可配置目录与文件列表，默认包含 `/var/log` 与 `./test.log`。可追加应用日志目录（如 `/var/log/nginx`）。
- `detectors`：支持 OOM、Panic、Reboot 三类检测，关键词与开关可在配置中调整。

## 权限与发行版差异
- 需要具备读取 `/var/log` 与 `journalctl` 的权限，必要时使用 `sudo`。
- 不同发行版的日志路径与服务设置存在差异，按需将相关目录加入 `log_paths`。

## 后续扩展
- 支持更多压缩格式（如 `.xz`）。
- 增加服务专用日志目录（nginx、ssh、docker 等）。
- 引入更丰富的匹配与解析策略，降低误报与漏报。