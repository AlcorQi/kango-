# 日志来源与说明

本项目用于在 Linux 系统中对常见系统与服务日志进行递归扫描，并基于关键词进行异常检测（OOM、Kernel panic、异常重启）。默认覆盖 `/var/log` 全目录，同时支持读取压缩旋转日志与 `systemd` 的 `journalctl` 文本输出。

## 检测范围
- 目录与文件：递归扫描 `log_paths` 中的目录与文件，默认包含 `/var/log` 与 `./test.log`（便于快速验证）。
- 文件识别规则：识别以 `.log` 结尾、包含 `.log.` 的文件，以及典型日志基名（如 `syslog`、`messages`、`kern.log`、`dmesg`、`auth.log`、`daemon.log`、`boot.log`、`cron`、`dpkg.log`、`apt/*.log`、`yum.log`、`pacman.log`、`audit.log`、`Xorg.*.log` 等）。
- 旋转与压缩：纳入历史周期日志如 `.log.1`、`.log.N`、`.N.gz` 等；`.gz` 文件使用文本模式解压读取。
- 排除二进制日志：跳过账户与会话类二进制日志（`wtmp`、`btmp`、`lastlog`、`faillog`、`utmp`），避免误读。
- `systemd`：在 Linux 环境且 `journalctl` 可用时，读取 `journalctl -o short-iso --no-pager` 文本输出，覆盖未写入 `/var/log` 的 systemd 单元事件。

## 日志类别与说明
- 系统总览
  - `syslog` / `messages`：系统范围事件与服务消息的汇总，最通用的系统日志来源。
  - 旋转版本：`syslog.1`、`syslog.N.gz` 等，用于历史追溯。
- 内核相关
  - `kern.log`：内核事件、驱动加载、硬件异常、调试信息。
  - `dmesg` / `dmesg.N.gz`：内核环形缓冲区快照，启动与硬件信息。
- 认证与安全
  - `auth.log` / `secure`：登录、sudo、认证失败、PAM 事件记录。
  - `audit/audit.log`：审计框架记录（SELinux/AppArmor、系统调用审计）。
- 启动与服务
  - `boot.log`：启动阶段服务加载与状态。
  - `daemon.log`：守护进程与系统服务消息。
  - `cron`：计划任务执行与失败。
- 图形与外设
  - `Xorg.*.log`：X 服务器图形驱动与显示相关日志。
  - GPU/虚拟化/设备：如 `gpu-manager.log`、`vmware-*` 等组件的运行记录。
- 包管理与升级
  - `dpkg.log` / `dpkg.log.N`：Debian 包安装/卸载/升级。
  - `apt/history.log`、`apt/term.log`：APT 操作历史与终端输出。
  - 其他发行版：`yum.log`、`pacman.log`（根据系统存在情况自动识别）。
- 打印与系统服务
  - `cups/access_log.*`：打印服务访问与作业记录。
  - `cloud-init.log`、`cloud-init-output.log`：云初始化流程与输出详情。
  - 安装器：`installer/*`（如 `subiquity`、`curtin`）安装过程与配置日志。
  - `fontconfig.log`：字体缓存与配置。

## 异常检测器与关键词
- OOM（内存不足）
  - 关键词示例：`Out of memory`、`oom-killer`、`Killed process`、`Memory cgroup out of memory`。
  - 严重级别：`high`。
- Kernel panic（内核恐慌）
  - 关键词示例：`Kernel panic`、`not syncing`、`System halted`。
  - 严重级别：`critical`。
- 异常重启
  - 关键词示例：`unexpectedly shut down`、`unexpected restart`、`system reboot`。
  - 严重级别：`medium`。

## 配置与扩展
- 配置文件：`config/default.yaml`
- 关键项：
  - `log_paths`：可配置目录与文件列表，默认包含 `/var/log` 与 `./test.log`。可追加应用日志目录（如 `/var/log/nginx`、`/var/log/myapp`），程序会递归扫描并按规则识别。
  - `detectors.*.enabled` 与 `detectors.*.keywords`：开关与关键词可自定义，以适配具体环境与日志语料。
- 排除与包含：
  - 如需排除某些子目录或特定大文件，可在枚举与识别规则处进行调整（例如排除特定路径、仅包含某前缀）。

## 使用与权限
- 建议在 Linux 环境运行，并具备读取 `/var/log` 与 `journalctl` 的权限。
- 若出现权限不足，使用具备管理员权限的用户或通过 `sudo` 运行。
- 各发行版日志路径与服务差异可能导致覆盖范围不同；将需要的目录加入 `log_paths` 可确保纳入扫描。

## 局限与后续扩展
- 压缩格式：当前支持 `.gz`，如需支持 `.xz` 等可扩展读取逻辑。
- 服务日志：可按需增加特定服务目录（如 `nginx`、`ssh`、`docker` 等）。
- 匹配策略：可引入正则与语义规则提升检测准确度，减少误报与漏报。

## 参考实现位置
- 递归扫描与过滤：`src/main.py:166-204`
- 日志文件识别规则：`src/main.py:184-195`
- 读取 `.gz` 压缩日志：`src/main.py:139-147`
- `journalctl` 文本输出读取：`src/main.py:205-232`
- 检测器调用与报告：`src/main.py:234-301`